/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1.Model;

/**
 *
 * @author Gustavo
 */
public class Aluno {
    private String Nome;
    private String Sobrenome;
    private String Nasc;
    private String Sexo;
    private double RA;
    private String Curso;
    
    public void SetNome(String x){
        Nome = x;
    }
    
    public void SetSobrenome(String x){
        Sobrenome = x;
    }
    
    public void SetNasc(String x){
        Nasc = x;
    }
 
    public void SetSexo(String x){
        Sexo = x;
    }
    
    public void SetRA(double x){
        RA = x;
    }
    
    public void SetCurso(String x){
        Curso = x;
    }
    
    public String GetNome(){
        String x = Nome;
        return x;
    }
    
    public String GetSobrenome(){
        String x = Sobrenome;
        return x;
    }
    
    public String GetNasc(){
        String x = Nasc;
        return x;
    }
 
    public String GetSexo(){
        String x = Sexo;
        return x;
    }
    
    public double GetRA(){
        double x = RA;
        return x;
    }
    
    public String GetCurso(){
        String x = Curso;
        return x;
    }
}
